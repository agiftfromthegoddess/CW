//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.ImgList.hpp>
#include <Vcl.ToolWin.hpp>
#include <Vcl.Dialogs.hpp>
#include <System.ImageList.hpp>
//---------------------------------------------------------------------------
#include <vector>
#include <algorithm>
#include <functional>
struct Phone{
		char firm[99];
		char model[99];
		char os[99];
		int year;
		int price;
		int index;

		friend bool operator<(const Phone& a,const Phone& b)
		{return a.year<b.year;}         // for sort by year
		friend bool operator==(const Phone& a,const Phone& b)
		{return a.year==b.year;}        // for search by year

		friend bool SortPrice(const Phone& a,const Phone& b)
		{return a.price<b.price;}         // for sort by price
		friend bool FindPrice( Phone a, Phone b)
		{return a.price==b.price;}        // for search by price

		bool SortFirm (char , char);


};
using namespace std;
extern vector <Phone> Phones;
extern int iMax,iCur;

class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TStringGrid *StringGrid1;
	TButton *Clear;
	TButton *View;
	TImageList *ImageList1;
	TToolBar *ToolBar1;
	TToolButton *ToolButton1;
	TToolButton *ToolButton2;
	TToolButton *ToolButton3;
	TToolButton *ToolButton4;
	TToolButton *ToolButton5;
	TButton *Button1;
	TEdit *Edit1;
	TButton *EditSearch;
	void __fastcall ViewClick(TObject *Sender);
	void __fastcall ToolButton1Click(TObject *Sender);
	void __fastcall ToolButton3Click(TObject *Sender);
	void __fastcall EditSearchClick(TObject *Sender);
	void __fastcall StringGrid1Enter(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
void __fastcall ShowRecord();
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
