﻿// ---------------------------------------------------------------------------
#include <vector>
#include <algorithm>
#include <functional>

#include <string>
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

vector<Phone>Phones;
int iMax = 0, iCur = 0;

// MY_CODE--------------------------------------------------------------------
// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner) {

}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ViewClick(TObject *Sender) {

	for (int i = 1; i <= Phones.size(); i++) {
		StringGrid1->Cells[0][0] = ("No");
		StringGrid1->Rows[0]->Add("Firm");
		StringGrid1->Rows[0]->Add("Model");
		StringGrid1->Rows[0]->Add("OS");
		StringGrid1->Rows[0]->Add("Year");
		StringGrid1->Rows[0]->Add("Price");
	}
	Form2->Show();
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Accept_FirmClick(TObject *Sender) {
	int j = 1;
	while (true) {
		if (Form1->StringGrid1->Cells[1][j].IsEmpty()) {
			Form1->StringGrid1->Cells[1][j] = Form2->Firm->Text;
			break;
		}
		else {
			j++;
		}
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Accept_ModelClick(TObject *Sender) {
	int j = 1;
	while (true) {
		if (Form1->StringGrid1->Cells[2][j].IsEmpty()) {
			Form1->StringGrid1->Cells[2][j] = Form2->Model->Text;
			break;
		}
		else {
			j++;
		}
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Accept_OSClick(TObject *Sender) {
	int j = 1;
	while (true) {
		if (Form1->StringGrid1->Cells[3][j].IsEmpty()) {
			Form1->StringGrid1->Cells[3][j] = Form2->OS->Text;
			break;
		}
		else {
			j++;
		}
	}
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
void __fastcall TForm2::Accept_YearClick(TObject *Sender) {
	int j = 1;
	bool a = 0;
	while (true) {
		if (Form1->StringGrid1->Cells[4][j].IsEmpty()) {
			for (int i = 0; i < 5; i++) {
				if (!Form1->StringGrid1->Cells[i][j].IsEmpty()) {
					j++;
					break;
				}
				else {
					continue;
				}
			}
			Form1->StringGrid1->Cells[4][j] = Form2->Year->Text;
			break;
		}
		else {
			j++;
		}
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Accept_PriceClick(TObject *Sender) {
	int j = 1;
	while (true) {
		if (Form1->StringGrid1->Cells[5][j].IsEmpty()) {
			Form1->StringGrid1->Cells[5][j] = Form2->Price->Text;
			break;
		}
		else {
			j++;
		}
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton1Click(TObject *Sender) {
	TStringList *tsl = new TStringList;
	tsl->Add(IntToStr(StringGrid1->RowCount));
	tsl->Add(IntToStr(StringGrid1->ColCount));
	for (int i = 0; i < StringGrid1->RowCount; i++) {
		tsl->AddStrings(StringGrid1->Rows[i]);
	}
	tsl->SaveToFile("Phones.txt");
	delete tsl;

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton3Click(TObject *Sender) {
	if (!Phones.empty())
		Phones.erase(Phones.begin(), Phones.end());

	TStringList *tsl = new TStringList;
	tsl->LoadFromFile("Phones.txt");
	StringGrid1->RowCount = StrToInt(tsl->Strings[0]);
	StringGrid1->ColCount = StrToInt(tsl->Strings[1]);
	int k = 2;

	for (int i = 0; i < StringGrid1->RowCount; i++) {

		for (int j = 0; j < StringGrid1->ColCount; j++) {
			StringGrid1->Cells[j][i] = tsl->Strings[k];
			k++;
		}

		if (i > 1) {
			Phone P;

			strcpy(P.firm, AnsiString(StringGrid1->Cells[1][i - 1]).c_str());
			strcpy(P.model, AnsiString(StringGrid1->Cells[2][i - 1]).c_str());
			strcpy(P.os, AnsiString(StringGrid1->Cells[3][i - 1]).c_str());
			P.year = StringGrid1->Cells[4][i - 1].ToIntDef(0);
			P.price = StringGrid1->Cells[5][i - 1].ToIntDef(0);
			Phones.push_back(P);
		}

	}
	delete tsl;

	ShowMessage(Phones.size());
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::EditSearchClick(TObject *Sender) {
	std::vector<Phone>::iterator q;
	std::vector<Phone>::iterator q2;
	Phone obj;
	if (!Edit1->Text.IsEmpty()) {
		q2 = Phones.begin();
		for (int j = 0; q != Phones.end(); j++) {
			obj.price = Edit1->Text.ToInt();
			ShowMessage("3");
			q = find_if(q2, Phones.end(),
				bind2nd(std::ptr_fun(FindPrice), obj));
			ShowMessage("5");
			if (q == Phones.end()) {
				ShowMessage("SEARCH IS ENDED");
				ShowMessage("7");
			}

			else {
				q2 = q + 1;
				std::string a;
				std::string b;
				std::string c;
				int d;
				int e;
				a = (*q).firm;
				b = (*q).model;
				c = (*q).os;
				d = (*q).year;
				e = (*q).price;
				a.append(" ");
				a.append(b);
				a.append(" ");
				a.append(c);
				a.append(" ");
				char AA[99];
				for (int i = 0; i < a.length(); i++) {
					AA[i] = a[i];
				}
				char CC[99];
				sprintf(CC, "%i %i", d, e);
				strcat(AA, CC);
				string BB = AA;

				ShowMessage(BB.c_str());
				break;
			}
		}
	}

	/* Phone p;
	 vector <Phone>::iterator h;
	 p.year=Edit1->Text.ToIntDef(0);
	 h=find(Phones.begin(),Phones.end(),p);
	 iCur=h-Phones.begin();
	 StringGrid1->Row=iCur+1; */
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::ShowRecord() {
	StringGrid1->RowCount = Phones.size() + 1;
	for (int i = 1; i <= Phones.size(); i++) {
		StringGrid1->Cells[0][i] = i;
		StringGrid1->Rows[i]->Add(Phones[i - 1].model);
		StringGrid1->Rows[i]->Add(Phones[i - 1].firm);
		StringGrid1->Rows[i]->Add(Phones[i - 1].os);
		StringGrid1->Rows[i]->Add(Phones[i - 1].year);
		StringGrid1->Rows[i]->Add(Phones[i - 1].price);
	}
}

// ---------------------------------------------------------------------------

void __fastcall TForm1::StringGrid1Enter(TObject *Sender) {
	StringGrid1->Rows[0]->Add("No");
	StringGrid1->Rows[0]->Add("Firm");
	StringGrid1->Rows[0]->Add("Model");
	StringGrid1->Rows[0]->Add("OS");
	StringGrid1->Rows[0]->Add("Year");
	StringGrid1->Rows[0]->Add("Price");

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender) {
bool SortFirm(Phones a, Phones b) {
	String aa, bb;
	aa = (a.firm).c_str();
	bb = (b.firm).c_str();
	return aa.ToInt() < bb.ToInt();

}
}
// ---------------------------------------------------------------------------
