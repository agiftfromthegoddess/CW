//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
	TButton *OK;
	TButton *Accept_Firm;
	TLabeledEdit *Firm;
	TLabeledEdit *Model;
	TButton *Accept_Model;
	TLabeledEdit *OS;
	TLabeledEdit *Year;
	TLabeledEdit *Price;
	TButton *Accept_OS;
	TButton *Accept_Year;
	TButton *Accept_Price;
	void __fastcall Accept_FirmClick(TObject *Sender);
	void __fastcall Accept_ModelClick(TObject *Sender);
	void __fastcall Accept_OSClick(TObject *Sender);
	void __fastcall Accept_YearClick(TObject *Sender);
	void __fastcall Accept_PriceClick(TObject *Sender);
	void __fastcall OKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
